<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /********************
     * Qaysi bulimga qancha bemor kelganligi
     * */
    public function patients_by_departments($start_date, $end_date)
    {
        $query = $this->db->query("
                SELECT d.id, d.`name` as department, count(pd.id) as count
                FROM `departments` d
                LEFT JOIN employees e on e.department_id = d.id
                LEFT JOIN patient_doctor pd on pd.doctor_id = e.id AND pd.created_date >= '".$start_date."' AND pd.created_date <= '".$end_date."'
                LEFT JOIN patients_payments pp on pp.id = pd.payment_id and pp.created_date IS NOT NULL
                where d.`status` = 1 and d.parent_id = 3  
                GROUP BY d.id
        ");


        return $query->result_array();
    }

    /********************
     * Kassaga tushgan pullar
     * */
    public function show_cash($start_date, $end_date)
    {
        $query = $this->db->query("
            SELECT sum(ppd.paid) as paid, SUM(pp.total - (ppd.paid + pp.discount)) as debt, SUM(pp.total) as total, pp.payment_type
            FROM patients_payments pp
            LEFT JOIN (
                SELECT ppd.payment_id, SUM(ppd.paid) as paid, SUM(ppd.by_cash) as by_cash, SUM(ppd.by_card) as by_card, SUM(ppd.by_bank) as by_bank
                FROM patients_payments_details ppd
                GROUP BY ppd.payment_id
            ) ppd ON ppd.payment_id = pp.id
            WHERE pp.created_date >= '".$start_date."' AND pp.created_date <= '".$end_date."'
            GROUP BY pp.payment_type
        ");


        return $query->result_array();
    }

    /**
     * kun buyicha tushum
     * @return int total_sum
     */
    public function get_total_income_by_date($start_date = null, $end_date = null) {

        $query = $this->db->query("
            (
                SELECT IFNULL(SUM(pp.total),0) as total, IFNULL(pp.payment_type,1) AS payment_type
                FROM patients_payments pp
                WHERE pp.created_date >= '".$start_date."' AND pp.created_date <= '".$end_date."' AND pp.payment_type = 1
            ) UNION (
                SELECT IFNULL(SUM(pp.total),0) as total, IFNULL(pp.payment_type,2) AS payment_type
                FROM patients_payments pp
                WHERE pp.created_date >= '".$start_date."' AND pp.created_date <= '".$end_date."' AND pp.payment_type = 2
            )
        ");

        return $query->result_array();

    }

    /********************
     * Malum vaqt oraligida doctorlarga tulangan pullarning umumiy hisobi
     * @param $start_date
     * @param $end_date
     * @return int
     */
    public function doctors_income_total($start_date, $end_date)
    {
        $query = $this->db->query("
            (
                SELECT IFNULL(SUM(b.amount),0) as total, IFNULL(b.payment_type,1) AS payment_type
                FROM `doctors_bill` b
                WHERE b.created_date >= '".$start_date."' AND b.created_date <= '".$end_date."' AND b.payment_type = 1
            ) UNION (
                SELECT IFNULL(SUM(b.amount),0) as total, IFNULL(b.payment_type,2) AS payment_type
                FROM `doctors_bill` b
                WHERE b.created_date >= '".$start_date."' AND b.created_date <= '".$end_date."' AND b.payment_type = 2
            )
        ");


        return $query->result_array();
    }

    /********************
     * Malum vaqt oraligida har-hil narsalarga sarflangan pullar xisobi
     * @param $start_date
     * @param $end_date
     * @return int
     */
    public function other_expenses_total($start_date, $end_date)
    {
        $query = $this->db->query("
            (
                SELECT IFNULL(SUM(e.amount),0) as total, IFNULL(e.payment_type,1) AS payment_type
                FROM expenses e
                WHERE e.created_date >= '".$start_date."' AND e.created_date <= '".$end_date."' AND e.payment_type = 1
            ) UNION (
                SELECT IFNULL(SUM(e.amount),0) as total, IFNULL(e.payment_type, 2) AS payment_type
                FROM expenses e
                WHERE e.created_date >= '".$start_date."' AND e.created_date <= '".$end_date."' AND e.payment_type = 2
            )
        ");

        return $query->result_array();
    }



}