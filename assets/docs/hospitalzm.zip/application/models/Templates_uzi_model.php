<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Templates_uzi_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /***********************************************
     * Templates Uzi
     * *********************************************/
    public function get_templates($doctor_id = null, $uzi_id = null)
    {
        if($doctor_id != null) {
            $this->db->where("doctor_id", $doctor_id);
        }

        if($uzi_id != null) {
            $this->db->where("u.id", $uzi_id);
        }
        $this->db->order_by("u.name");
        $this->db->select("tu.*, u.name");
        $this->db->join("uzi u", "u.id = tu.uzi_id");
        $query = $this->db->get("templates_uzi tu");

        return $query->result_array();
    }

    public function get_template($id)
    {
        $this->db->select("tu.*, u.name");
        $this->db->join("uzi u", "u.id = tu.uzi_id");
        $this->db->where('tu.id', $id);
        $query = $this->db->get("templates_uzi tu");

        return $query->row_array();
    }

    public function add($arr)
    {
        $this->db->insert("templates_uzi", $arr);

        return $this->db->insert_id();
    }

    public function update($id, $arr)
    {
        $this->db->where('id', $id);
        return $this->db->update("templates_uzi", $arr);

    }

    public function delete($id)
    {
        $this->db->where("id", $id);
        return $this->db->delete("templates_uzi");
    }

}