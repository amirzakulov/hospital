<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uzi extends Admin_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model(array("uzi_model"));
        $this->load->language("uzi");
    }

    /*************************************************************************************************
     *                                  Uzi                                                          *
     **************************************************************************************************/

    public function index()
    {
        $this->data['title'] = lang("uzi_title");
        $this->data['before_themeStyle'] = '<link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">';

        $this->data['before_appjs'] = '<script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>';

        $uzis = $this->uzi_model->get_uzis();

        $this->data["uzis"] = $uzis;
        $this->render('admin/uzi/index_view');
    }

    public function add()
    {
        $this->data["title"] = lang("uzi_add_title");

        $was_validated = "";

        $prefix = "uzi";
        $max_id = max_id("uzi");
        $code = uniqe_code_genetrator($prefix, $max_id, 4);

        // validate form input
        $this->form_validation->set_rules('name', $this->lang->line('uzi_name'), 'trim|required');
        $this->form_validation->set_rules('price', $this->lang->line('uzi_price'), 'trim');

        if ($this->form_validation->run() === TRUE)
        {
            $renew = is_null($this->input->post("renew")) ? false:true;
            unset($_POST["renew"]);

            $_POST["code"] = $code;
            $this->uzi_model->add($this->input->post());

            if($renew) {
                redirect("admin/uzi/add/", 'refresh');
            } else {
                redirect("admin/uzi", 'refresh');
            }

        }
        else
        {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if(!empty($this->data['message']))
            {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $this->data['name'] = [
                'name'  => 'name',
                'id'    => 'name',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('name'),
                "class" => "form-control",
                "required" => "",
                "tabindex" => 1
            ];

            $this->data['price'] = [
                'name'  => 'price',
                'id'    => 'price',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('price'),
                "class" => "form-control",
                "required" => "",
                "tabindex" => 2
            ];

            $this->render("admin/uzi/add_view");
        }
    }

    public function edit($id)
    {
        $this->data["title"] = lang("uzi_edit_title");

        $uzi = $this->uzi_model->get_uzi($id);
        $was_validated = "";

        // validate form input
        $this->form_validation->set_rules('name', $this->lang->line('uzi_name'), 'trim|required');
        $this->form_validation->set_rules('price', $this->lang->line('uzi_price'), 'trim');

        if ($this->form_validation->run() === TRUE)
        {
            $id = $this->uzi_model->update($id, $this->input->post());

            redirect("admin/uzi", 'refresh');
        }
        else
        {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if(!empty($this->data['message']))
            {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $this->data['name'] = [
                'name'  => 'name',
                'id'    => 'name',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('name', $uzi["name"]),
                "class" => "form-control",
                "required" => ""
            ];

            $this->data['price'] = [
                'name'  => 'price',
                'id'    => 'price',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('price', $uzi["price"]),
                "class" => "form-control",
                "required" => ""
            ];

            $this->render("admin/uzi/edit_view");
        }
    }


    /**
     * @var boolean linked - usbu item boshqa table larga bog'langanmi yoqmiligini bildiradi (true - bog'langan, false - bog'lanmagan)
     **/
    public function delete()
    {
        $id = $this->input->post("id");
        if(!is_null($this->input->post("confirm")))
        {
            $deleted = $this->uzi_model->delete($id);
            echo json_encode(array("deleted" => $deleted));
        }
        else
        {
            $linked = $this->uzi_model->check_links($id);
            if($linked > 0) {
                echo json_encode(true);
            } else {
                echo json_encode(false);
            }
        }
    }

}
