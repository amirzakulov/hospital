<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends Admin_Controller {
    private  $user_id;

    function __construct()
    {
        parent::__construct();

        $this->load->model(
            array(
                "reports_model",
                "patients_model",
//                "users_model",
//                "doctors_model",
                "patient_doctor_model",
                "patient_laboratories_model",
                "patient_uzi_model",
                "patient_room_model",
                "patient_service_model",
                "patients_payments_model",
//                "regions_model",
//                "cities_model",
//                "expenses_model",
				"payment_types_model",
				"payments_debt_discount_model",
            ));

        $this->load->language("patients");
        $this->user_id = $this->session->userdata("user_id");

    }

	public function index($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Умумий хисобот";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/jquery.sticky.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] 		= $this->show_cash($start_date, $end_date);
		$this->data["income"] 		= $this->patients_payments_model->income_by_items($start_date, $end_date);
        $this->data["from_old_debts"] = $this->payments_debt_discount_model->from_old_debts($start_date, $end_date);
        $this->data["expenditure"] 	= $this->expenses_model->get_expenses_by_type($start_date, $end_date);
		$this->data["expenditure_payment_types"] = $this->expenses_model->get_expenses_payment_type($start_date, $end_date);
		$this->data["last_payments"]= $this->patients_payments_model->get_payments(date("Y-m-d"), null, 5);
//		$this->data["last_payments"]= $this->patients_model->get_paid_patients_by_date(date("Y-m-d"), false, 5);


        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]   			= strtotime($start_date);
		$this->data["edate"]     		= strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/index_view");
	}

	public function doctors($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Шифокорлар";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"]     = $this->show_cash($start_date, $end_date);
		$this->data["doctors"]  = $this->patient_doctor_model->get_doctors_by_date($start_date, $end_date);

        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]= strtotime($start_date);
		$this->data["edate"]= strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/doctors_view");
	}

    public function doctors_patients($doctor_id = null, $start_date = null, $end_date = null)
    {
        if(is_null($doctor_id)) {
            redirect("admin/reports");
        }

        $this->data["title"] = "Беморлар";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

        $this->data["patients"] = $this->patient_doctor_model->get_doctor_patients_by_date($doctor_id, $start_date, $end_date);

        $this->mybreadcrumb->add('Шифокорлар', site_url("admin/reports/doctors/".$start_date_param."/".$end_date_param));
        $this->mybreadcrumb->add('Беморлар', "admin/reports/doctors_patients/");
        $this->data['breadcrumbs'] = $this->mybreadcrumb->render();

        $this->render("admin/reports/doctors_patients_view");

	}

	public function laboratory($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Лаборатория";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] 		= $this->show_cash($start_date, $end_date);
		$this->data["laboratories"] = $this->patient_laboratories_model->get_laboratories_by_date($start_date, $end_date);

        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]   = strtotime($start_date);
		$this->data["edate"]   = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/laboratory_view");
	}

	public function uzi($start_date = null, $end_date = null)
	{
		$this->data["title"] = "УЗИ";

		$start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
		$end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

		$start_date_param = date("Ymd", strtotime($start_date));
		$end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

			$start_date_param = date("Ymd", strtotime($start_date));
			$end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] = $this->show_cash($start_date, $end_date);
		$this->data["uzis"] = $this->patient_uzi_model->get_uzis_by_date($start_date, $end_date);
		$this->data["start_date_param"] = $start_date_param;
		$this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]   = strtotime($start_date);
		$this->data["edate"]   = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/uzi_view");
	}

    public function services($start_date = null, $end_date = null)
    {
        $this->data["title"] = "Қўшимча хизматлар";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

        $this->form_validation->set_rules('start_date', 'start_date', 'trim');
        $this->form_validation->set_rules('end_date', 'end_date', 'trim');

        if ($this->form_validation->run() === TRUE) {
            $start_date = date_formating(strtotime($this->input->post("start_date")), "db");
            $end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
        }

        $this->data["cash"] = $this->show_cash($start_date, $end_date);
        $this->data["services"]= $this->patient_service_model->get_service_by_date($start_date, $end_date);
        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

        $this->data["sdate"]   = strtotime($start_date);
        $this->data["edate"]     = strtotime($end_date);

        $this->data['start_date'] = [
            'name'  => 'start_date',
            'id'    => 'start_date',
            'type'  => 'text',
            'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];
        $this->data['end_date'] = [
            'name' => 'end_date',
            'id' => 'end_date',
            'type' => 'text',
            'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];

        $this->render("admin/reports/services_view");
    }

	public function room($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Ётоқ";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] = $this->show_cash($start_date, $end_date);
		$this->data["rooms"]= $this->patient_room_model->get_room_by_date($start_date, $end_date);
        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]= strtotime($start_date);
		$this->data["edate"]= strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/room_view");
	}

	public function expenses($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Чиқимлар";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] = $this->show_cash($start_date, $end_date);
		$this->data["expenditure"]  = $this->expenses_model->get_expenses($start_date, $end_date, true);
        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"] = strtotime($start_date);
		$this->data["edate"] = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/expenses_view");
	}

	public function doctors_bill($start_date = null,  $end_date = null)
	{
		$this->data["title"] = "Чиқимлар";

        $start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
        $end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

        $start_date_param = date("Ymd", strtotime($start_date));
        $end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

            $start_date_param = date("Ymd", strtotime($start_date));
            $end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"] = $this->show_cash($start_date, $end_date);
		$this->data["doctors_bill"] = $this->doctors_bill_model->get_doctors_bill($start_date, $end_date, true);
        $this->data["start_date_param"] = $start_date_param;
        $this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"] = strtotime($start_date);
		$this->data["edate"] = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/doctors_bill_view");
	}

    public function patients() {
        $start_date = date("Y-m-d");
        $end_date   = date("Y-m-d", strtotime($start_date." +1 days"));

        $this->data['title'] = 'Беморлар';
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';


        $this->form_validation->set_rules('start_date', 'start_date', 'trim');
        $this->form_validation->set_rules('end_date', 'end_date', 'trim');

        if ($this->form_validation->run() === TRUE) {

            $start_date = date("Y-m-d", strtotime($this->input->post("start_date")));
            $end_date = date("Y-m-d", strtotime($this->input->post("end_date")));
        }


        $this->data["reports"] = $this->reports_model->patients_by_departments($start_date, $end_date);

        $this->data["sdate"]   = strtotime($start_date);
        $this->data["edate"]     = strtotime($end_date);

        $this->data['start_date'] = [
            'name'  => 'start_date',
            'id'    => 'start_date',
            'type'  => 'text',
            'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];
        $this->data['end_date'] = [
            'name' => 'end_date',
            'id' => 'end_date',
            'type' => 'text',
            'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];

        $this->data["patients"] = array();

        $this->render('admin/reports/patients_view');
    }

    public function general2()
    {
        $start_date = date("Y-m-d");
        $end_date   = date("Y-m-d", strtotime($start_date." +1 days"));

        $this->data["title"] = "Касса";
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';


        $this->form_validation->set_rules('start_date', 'oaudoafsd', 'trim');
        $this->form_validation->set_rules('end_date', 'end_date', 'trim');

        if ($this->form_validation->run() === TRUE) {
            $start_date = date("Y-m-d", strtotime($this->input->post("start_date")));
            $end_date = date("Y-m-d", strtotime($this->input->post("end_date")));
        }


        $this->data["payment_types"]    = array(1 => "Нақд", 2 => "Пластик");
        $this->data["total_income"]     = $this->reports_model->get_total_income_by_date($start_date, $end_date);
        $this->data["doctors_income"]   = $this->reports_model->doctors_income_total($start_date, $end_date);
        $this->data["expenses"]         = $this->reports_model->other_expenses_total($start_date, $end_date);

        $this->data["sdate"]   = strtotime($start_date);
        $this->data["edate"]   = strtotime($end_date);

        $this->data['start_date'] = [
            'name'  => 'start_date',
            'id'    => 'start_date',
            'type'  => 'text',
            'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];
        $this->data['end_date'] = [
            'name' => 'end_date',
            'id' => 'end_date',
            'type' => 'text',
            'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];


        $this->render('admin/reports/general_view');
    }

    public function payments()
    {
        $start_date = date("Y-m-d");
        $end_date   = date("Y-m-d", strtotime($start_date." +1 days"));

        $this->data["title"] = "Касса";
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';


        $this->form_validation->set_rules('start_date', 'oaudoafsd', 'trim');
        $this->form_validation->set_rules('end_date', 'end_date', 'trim');

        if ($this->form_validation->run() === TRUE) {
            $start_date = date("Y-m-d", strtotime($this->input->post("start_date")));
            $end_date = date("Y-m-d", strtotime($this->input->post("end_date")));
        }


        $this->data["payment_types"] = array(1 => "Нақд", 2 => "Пластик");
        $this->data["payments"] = $this->patients_payments_model->get_total_income_by_date($start_date, $end_date, true);


        $this->data["sdate"]   = strtotime($start_date);
        $this->data["edate"]     = strtotime($end_date);

        $this->data['start_date'] = [
            'name'  => 'start_date',
            'id'    => 'start_date',
            'type'  => 'text',
            'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];
        $this->data['end_date'] = [
            'name' => 'end_date',
            'id' => 'end_date',
            'type' => 'text',
            'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
            "class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
        ];


        $this->render('admin/reports/payments_view');

    }

	private function show_cash($start_date, $end_date) {
		$this->load->model(array("expenses_model", "doctors_bill_model"));
//		$income		  = $this->patients_payments_model->show_cash($start_date, $end_date);
        $total_payment = $this->patients_payments_model->total_payment($start_date, $end_date);
        $real_payment = $this->patients_payments_model->real_payment($start_date, $end_date);
        $debt         = $this->patients_payments_model->debt($start_date, $end_date);
		$expenditure  = $this->expenses_model->get_expenses($start_date, $end_date);
		$expenditure  = !empty($expenditure) ? $expenditure:0;
		$doctors_bill = $this->doctors_bill_model->get_doctors_bill($start_date, $end_date);
		$doctors_bill = !empty($doctors_bill) ? $doctors_bill:0;

		return array("total_payment" => $total_payment, "real_payment" => $real_payment, "debt" => $debt, "expenditure" => $expenditure, "doctors_bill" => $doctors_bill);
	}

	public function cash()
	{
		$start_date = date("Y-m-d");
		$end_date   = date("Y-m-d", strtotime($start_date." +1 days"));

		$this->data["title"] = "Касса";
		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';


		$this->form_validation->set_rules('start_date', 'oaudoafsd', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date("Y-m-d", strtotime($this->input->post("start_date")));
			$end_date = date("Y-m-d", strtotime($this->input->post("end_date")));
		}


		$this->data["payment_types"] = array(1 => "Нақд", 2 => "Пластик");
		$this->data["reports"] = $this->reports_model->show_cash($start_date, $end_date);

		$this->data["sdate"]   = strtotime($start_date);
		$this->data["edate"]     = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];


		$this->render('admin/reports/cash_view');

	}

    public function from_old_debts($start_date = null, $end_date = null)
    {
		$this->data["title"] = "Эски қарзлардан";

		$start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
		$end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

		$start_date_param = date("Ymd", strtotime($start_date));
		$end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

			$start_date_param = date("Ymd", strtotime($start_date));
			$end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"]     = $this->show_cash($start_date, $end_date);
		$this->data["patients"]  = $this->patients_payments_model->get_debt_off_by_date($start_date, $end_date);

		$this->data["start_date_param"] = $start_date_param;
		$this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]= strtotime($start_date);
		$this->data["edate"]= strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

        $this->render("admin/reports/from_old_debts_view");

    }

	public function uzi2($start_date = null, $end_date = null)
	{
		$this->data["title"] = "УЗИ";

		$start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
		$end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

		$start_date_param = date("Ymd", strtotime($start_date));
		$end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

			$start_date_param = date("Ymd", strtotime($start_date));
			$end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["uzis"] = $this->patient_uzi_model->get_uzis_by_date($start_date, $end_date);
		$this->data["start_date_param"] = $start_date_param;
		$this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]   = strtotime($start_date);
		$this->data["edate"]   = strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/uzi2_view");
	}

	public function debts($start_date = null, $end_date = null)
	{
		$this->data["title"] = "Қарздорлар";

		$start_date = is_null($start_date) ? date("Y-m-d") : date("Y-m-d", strtotime($start_date));
		$end_date   = is_null($end_date) ? date("Y-m-d") : date("Y-m-d", strtotime($end_date));

		$start_date_param = date("Ymd", strtotime($start_date));
		$end_date_param   = date("Ymd", strtotime($end_date));

		$this->data['before_themeStyle'] = '
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
            <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        ';

		$this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        ';

		$this->form_validation->set_rules('start_date', 'start_date', 'trim');
		$this->form_validation->set_rules('end_date', 'end_date', 'trim');

		if ($this->form_validation->run() === TRUE) {
			$start_date = date_formating(strtotime($this->input->post("start_date")), "db");
			$end_date 	= date_formating(strtotime($this->input->post("end_date")), "db");

			$start_date_param = date("Ymd", strtotime($start_date));
			$end_date_param   = date("Ymd", strtotime($end_date));
		}

		$this->data["cash"]     = $this->show_cash($start_date, $end_date);
		$this->data["patients"]  = $this->patients_model->get_debitor_patients_by_date($start_date, $end_date);

		$this->data["start_date_param"] = $start_date_param;
		$this->data["end_date_param"]   = $end_date_param;

		$this->data["sdate"]= strtotime($start_date);
		$this->data["edate"]= strtotime($end_date);

		$this->data['start_date'] = [
			'name'  => 'start_date',
			'id'    => 'start_date',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('start_date', date("d.m.Y", strtotime($start_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];
		$this->data['end_date'] = [
			'name' => 'end_date',
			'id' => 'end_date',
			'type' => 'text',
			'value' => $this->form_validation->set_value('end_date', date("d.m.Y", strtotime($end_date))),
			"class" => "form-control mb-2 mr-sm-2 datetimepicker-salary",
		];

		$this->render("admin/reports/debts_view");

	}

}
