<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Templates_uzi extends Doctor_Controller {

    private $doctor_id;
    function __construct()
    {
        parent::__construct();

        $this->load->model(array("patients_payments_model", "templates_uzi_model", "uzi_model"));
        $this->load->language("templates_uzi");
        $this->doctor_id = $this->session->userdata("employee_id");
    }

    public function index() {
        $this->data['title'] = 'Андозалар';
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        ';

        $this->data["lang"] = array(1 => "Ўзбек", 2 => "Рус", 3 => "Инглиз", );
        $templates_res = $this->templates_uzi_model->get_templates($this->doctor_id);
        $templates = array();
        foreach ($templates_res as $t) {
            $templates[$t["name"]][] = $t;
        }
        $this->data["templates"] = $templates;

        $this->render('doctor/templates_uzi/index_view');
    }

    public function add()
    {
        $this->data["title"] = "Бемор қўшиш";
        $this->data['before_themeStyle'] = '
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/js/lou_multi_select/multi-select.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/richtexteditor/richtext.min.css").'">
                                        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/lou_multi_select/jquery.multi-select.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/doctor/js/richtexteditor/jquery.richtext.min.js").'"></script>
                                        ';

        $was_validated      = "";

        $uzis = $this->uzi_model->get_uzis();
        $uzi_id_options = array("" => "--Танланмаган--");
        foreach ($uzis as $uzi) {
            $uzi_id_options[$uzi["id"]] = $uzi["name"];
        }

        $this->data["uzi_id_options"] = $uzi_id_options;

        // validate form input
        $this->form_validation->set_rules('uzi_id', $this->lang->line('add_validation_uzi_id_label'), 'trim|required');
        $this->form_validation->set_rules('title', $this->lang->line('add_validation_title_label'), 'trim|required');
        $this->form_validation->set_rules('template', $this->lang->line('add_validation_template_label'), 'trim');

        if ($this->form_validation->run() === TRUE) {
            $_POST["doctor_id"] = $this->doctor_id;
            $this->templates_uzi_model->add($this->input->post());
            $this->session->set_flashdata('message', $this->ion_auth->messages());

            redirect("doctor/templates_uzi", 'refresh');
        } else {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if (!empty($this->data['message'])) {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $this->data['uzi_id'] = [
                'name'  => 'uzi_id',
                'id'    => 'uzi_id',
                'value' => $this->form_validation->set_select('uzi_id'),
                'class' => 'custom-select',
                "required" => ""
            ];

            $this->data['template_title'] = [
                'name'  => 'title',
                'id'    => 'title',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('title'),
                "class" => "form-control",
                "required" => ""
            ];
            $this->data['template_text'] = [
                'name' => 'template',
                'id' => 'template',
                'type' => 'textarea',
                'value' => $this->form_validation->set_value('template'),
                "class" => "form-control rich_text_content",
                "required" => "",
                'rows' => 10,
                'cols' => 30,
            ];
            $this->data['description'] = [
                'name' => 'description',
                'id' => 'description',
                'type' => 'textarea',
                'value' => $this->form_validation->set_value('description'),
                'rows' => 2,
                'cols' => 30,
                'class' => 'form-control'
            ];
        }

        $this->render("doctor/templates_uzi/add_view");

    }

    public function edit($id)
    {
        $this->data["title"] = "Бемор қўшиш";
        $this->data['before_themeStyle'] = '
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/js/lou_multi_select/multi-select.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/richtexteditor/richtext.min.css").'">
                                        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/lou_multi_select/jquery.multi-select.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/doctor/js/richtexteditor/jquery.richtext.min.js").'"></script>
                                        ';

        $was_validated      = "";

        $uzis = $this->uzi_model->get_uzis();
        $uzi_id_options = array("" => "--Танланмаган--");
        foreach ($uzis as $uzi) {
            $uzi_id_options[$uzi["id"]] = $uzi["name"];
        }

        $this->data["uzi_id_options"] = $uzi_id_options;

        $template = $this->templates_uzi_model->get_template($id);
        $this->data["template"] = $template;

        // validate form input
        $this->form_validation->set_rules('uzi_id', $this->lang->line('edit_validation_uzi_id_label'), 'trim|required');
        $this->form_validation->set_rules('title', $this->lang->line('edit_validation_title_label'), 'trim|required');
        $this->form_validation->set_rules('template', $this->lang->line('edit_validation_template_label'), 'trim');

        if ($this->form_validation->run() === TRUE) {
            $this->templates_uzi_model->update($id, $this->input->post());
            $this->session->set_flashdata('message', $this->ion_auth->messages());

            redirect("doctor/templates_uzi", 'refresh');
        } else {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if (!empty($this->data['message'])) {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $this->data['uzi_id'] = [
                'name'  => 'uzi_id',
                'id'    => 'uzi_id',
                'value' => $this->form_validation->set_select('uzi_id', $template["uzi_id"]),
                'class' => 'custom-select',
                "required" => ""
            ];

            $this->data['template_title'] = [
                'name'  => 'title',
                'id'    => 'title',
                'type'  => 'text',
                'value' => $this->form_validation->set_value('title', $template["title"]),
                "class" => "form-control",
                "required" => ""
            ];
            $this->data['template_text'] = [
                'name' => 'template',
                'id' => 'template',
                'type' => 'textarea',
                'value' => $this->form_validation->set_value('template', $template["template"]),
                "class" => "form-control rich_text_content",
                "required" => "",
                'rows' => 10,
                'cols' => 30,
            ];
            $this->data['description'] = [
                'name' => 'description',
                'id' => 'description',
                'type' => 'textarea',
                'value' => $this->form_validation->set_value('description', $template["description"]),
                'rows' => 2,
                'cols' => 30,
                'class' => 'form-control'
            ];
        }

        $this->render("doctor/templates_uzi/edit_view");

    }

    public function tview($id)
    {
        $this->data["title"] = "Андоза";

        $this->data["template"] = $this->templates_uzi_model->get_template($id);

        $this->render("doctor/templates_uzi/view_view");

    }

    public function delete()
    {
        $id = $this->input->post("id");
        $result = $this->templates_uzi_model->delete($id);
        echo json_encode(array("action" => "deleted"));
    }

    public function add_batch()
    {
        $this->data["title"] = "Бемор қўшиш";
        $this->data['before_themeStyle'] = '
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/js/lou_multi_select/multi-select.css").'">
                                        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/richtexteditor/richtext.min.css").'">
                                        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/lou_multi_select/jquery.multi-select.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/doctor/js/richtexteditor/jquery.richtext.min.js").'"></script>
                                        ';

        $was_validated      = "";


        $uzis = $this->uzi_model->get_uzis();
        $uzi_id_options = array("" => "--Танланмаган--");
        foreach ($uzis as $uzi) {
            $uzi_id_options[$uzi["id"]] = $uzi["name"];
        }

        $this->data["uzi_id_options"] = $uzi_id_options;
        $this->data["lang_options"] = array(1=>"Ўзб", 2=>"Рус", 3=>"Инг");

        // validate form input
        $this->form_validation->set_rules('uzi_id', $this->lang->line('add_validation_uzi_id_label'), 'trim|required');

        if ($this->form_validation->run() === TRUE) {
            $file = "";
            $template = "";

            //upload qilingan fileni qayta ishlaymiz
            $config['upload_path']      = FCPATH."uploads/temp";
            $config['allowed_types']    = 'docx';
            $config['max_size']         = '0';

            $this->load->library('upload',$config);

            if ( ! $this->upload->do_upload('userfile')) {
                $error = array('error' => $this->upload->display_errors());
            } else {
                $file = $this->upload->data();
            }

            //agar file upload qilingan bulsa, filedan malumotlarini olamiz
            if(!empty($file)) {
                $this->load->library("phpword");
                $template = $this->phpword->readWordDocx($file["full_path"]);
            }

            $_POST["doctor_id"] = $this->doctor_id;
            $_POST["title"] = str_replace($file["file_ext"], "", $file["client_name"]);
            $_POST["template"] = $template;

            //malumotlarni bazaga yozamiz
            $this->templates_uzi_model->add($this->input->post());

            //vaqtincha saqlangan fileni uchirib tashlaymiz
            $this->load->helper('file');
            delete_files($file["file_path"]);

            redirect("doctor/templates_uzi", 'refresh');
        } else {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if (!empty($this->data['message'])) {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $this->data['lang'] = [
                'name'  => 'lang',
                'id'    => 'lang',
                'value' => $this->form_validation->set_select('lang'),
                'class' => 'custom-select',
                "required" => ""
            ];

            $this->data['uzi_id'] = [
                'name'  => 'uzi_id',
                'id'    => 'uzi_id',
                'value' => $this->form_validation->set_select('uzi_id'),
                'class' => 'custom-select',
                "required" => ""
            ];

            $this->data['template_file_upload'] = [
                'name'  => 'userfile',
                'id'    => 'userfile',
                'type'  => 'file',
                'value' => $this->form_validation->set_value('userfile'),
                "class" => "form-control",
                "required" => ""
            ];
        }

        $this->render("doctor/templates_uzi/add_batch_view");

    }
}
