<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Patients_uzi extends Doctor_Controller {

    private $doctor_id;
    function __construct()
    {
        parent::__construct();

        if(!$this->ion_auth->in_group(9)) {
            show_404("", false);
            exit("sizning xuquqingiz yetarli emas!!!");
        }

        $this->load->model(
            array(
                "patients_model",
                "doctors_model",
                "patient_doctor_model",
                "uzi_model",
                "patient_uzi_model",
                "partners_model",
                "patients_payments_model",
                "templates_uzi_model",
                "files_model",
                "regions_model",
                "cities_model",
            ));

        $this->load->language("doctor_patients_uzi");
        $this->doctor_id = $this->session->userdata("employee_id");
    }

    public function index() {

        $this->data['title'] = 'Беморлар';
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        ';

        $patients = $this->patients_payments_model->get_uzi_patients();

        $this->data["incomplete_patients"] = $patients["incomplete"];
        $this->data["completed_patients"] = $patients["completed"];

        $this->render('doctor/patients_uzi/index_view');
    }

    /**
     * doctorning barcha bemorlari ruyhati
     * **/
    public function all()
    {
        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/dataTables.bootstrap4.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        ';
        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/admin/js/jquery.dataTables.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/dataTables.bootstrap4.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        ';

        $patients = $this->patient_uzi_model->get_all_patients();

        $this->data["patients"] = $patients;

        $this->render('doctor/patients_uzi/all_view');
    }


    public function patient_backup($payment_id) {

        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/print.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/richtexteditor/richtext.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/doctor/js/print.min.js").'"></script>
                                        <script src="'.site_url("assets/doctor/js/richtexteditor/jquery.richtext.min.js").'"></script>
                                        ';

        $this->data["print_preview_url"] = site_url("doctor/patients_uzi/ajax_print_preview");

        //Bemor haqidagi ma'lumotlar
        $patient = $this->patient_uzi_model->get_patient($payment_id);
        $this->data["patient"]      = $patient;

        //Bemorning aktiv uzilari
        $patient_active_uzis = $this->patient_uzi_model->get_patient_uzi($payment_id);
        $this->data["patient_active_uzis"] = $patient_active_uzis;

        $first_uzi_id = $patient_active_uzis[0]["uzi_id"];
        $templates = $this->templates_uzi_model->get_templates($this->doctor_id, $first_uzi_id);
        $uzi_templates = array();
        foreach ($templates as $template) {
            $uzi_templates[$template["id"]] = $template["title"];
        }

        $this->data["uzi_templates"] = $uzi_templates;

        $payments = $this->patients_payments_model->get_patient_payment_by_patient($patient["patient_id"]);
        $this->data["payments"] = $payments;
        $was_validated = "";

        $this->form_validation->set_rules('result[]', $this->lang->line('doctor_patients_uzi_validation_result_label'), 'trim');

        if ($this->form_validation->run() === TRUE) {

            $this->session->set_flashdata('message', $this->ion_auth->messages());

            redirect("doctor/patients_uzi", 'refresh');
        } else {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if (!empty($this->data['message'])) {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

            $script = '<script type="text/javascript">';
            foreach ($patient_active_uzis as $uzi) {
                //richtext plugin bitta pageda 1 dan ortiq ishlashi uchun, class larini har xil qilib olamiz
                $clas = ".rich_text_content_".$uzi["id"];
                $script .= '$("'.$clas.'").richText();';

//                $result_value = $uzi["result"];
//                if(empty($uzi["result"])) {
//                    $result_value = $templates[0]["template"];
//                }

                $this->data['result'][] = [
                    'name'  => 'result[]',
                    'id'    => $uzi["id"],
                    'type'  => 'textarea',
                    'class' => 'form-control rich_text_content_'.$uzi["id"],
                    'value' => $this->form_validation->set_value('result'),
                    "required" => "",
                    'rows'  => 10,
                    'cols'  => 30,
                    'disabled'=> "disabled"
                ];
            }
            $script .= '</script>';

            $this->data["before_body"] = $script;
        }

        $this->render('doctor/patients_uzi/patient_view');
    }

    public function patient($payment_id) {

        $this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/print.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/richtexteditor/richtext.min.css").'">
        ';

        $this->data['before_appjs'] = '
                                        <script src="'.site_url("assets/doctor/js/print.min.js").'"></script>
                                        <script src="'.site_url("assets/doctor/js/richtexteditor/jquery.richtext.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
                                        <script src="'.site_url("assets/admin/js/jquery.sticky.js").'"></script>
                                        ';

        $this->data["print_preview_url"] = site_url("doctor/patients_uzi/ajax_print_preview");

        //Bemor haqidagi ma'lumotlar
        $patient = $this->patient_uzi_model->get_patient($payment_id);
        $this->data["patient"]      = $patient;

        //Bemorning aktiv uzilari
        $patient_active_uzis = $this->patient_uzi_model->get_patient_uzi($payment_id);
        $this->data["patient_active_uzis"] = $patient_active_uzis;

        $payments = $this->patients_payments_model->get_patient_payment_by_patient($patient["patient_id"]);
        $this->data["payments"] = $payments;
        $was_validated = "";

        $this->form_validation->set_rules('userfile', $this->lang->line('doctor_patients_uzi_file'), 'callback_file_selected');

        if ($this->form_validation->run() === TRUE) {


            //upload qilingan fileni qayta ishlaymiz
            $file_name = 'uzi_'.date("d_m_Y_H_i");
            $config['upload_path']      = FCPATH."uploads/services";
            $config['allowed_types']    = 'docx';
            $config['max_size']         = '0';
            $config['file_name']        = $file_name;

            $this->load->library('upload',$config);

            if ( ! $this->upload->do_upload('userfile')) {
                $this->form_validation->set_message('file_selected', "Файл тури нотўғри");
                $this->data['message'] = "Файл тури нотўғри";

                if (!empty($this->data['message'])) {
                    $was_validated = "was-validated";
                }
                $this->data["was_validated"] = $was_validated;
            } else {

                $file = $this->upload->data();

                //agar file upload qilingan bulsa, filedan malumotlarini olamiz
                if(!empty($file)) {
                    $this->load->library("phpword");
                    $template = $this->phpword->readWordDocx($file["full_path"]);
                }

                $file_array = array(
                    "filename" => $file["file_name"],
                    "service_type"=>3,
                    "payment_id"=> $payment_id,
                    "employee_id" => $this->doctor_id,
                    "result" => $template
                );

                $this->files_model->add($file_array);
                $uzi_data = array("uzi_status" => 2, "order_status" => 0);
                $this->patients_payments_model->update($payment_id, $uzi_data);

                //barcha servicelar berkitilganligini tekshirib keyin status ni update qilamiz
                $status   = $this->patients_payments_model->check_payment_status($payment_id) == 'completed' ? 1:0;
                $this->patients_payments_model->update($payment_id, array("status" => $status));

                $this->session->set_flashdata('message', $this->ion_auth->messages());

                redirect("doctor/patients_uzi", 'refresh');
            }

        } else {
            // display the create user form
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            if (!empty($this->data['message'])) {
                $was_validated = "was-validated";
            }
            $this->data["was_validated"] = $was_validated;

        }

        $this->render('doctor/patients_uzi/patient_view');
    }

    function file_selected(){

        $this->form_validation->set_message('file_selected', 'Илтимос файлни танланг');
        if (empty($_FILES['userfile']['name'])) {
            return false;
        }else{
            return true;
        }
    }

    public function patient_info($payment_id)
    {
        $this->data["refer"] = site_url("doctor/patients_uzi");

        $this->data['before_themeStyle'] = '<link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/print.min.css").'">';
        $this->data['before_appjs'] = '<script src="'.site_url("assets/admin/js/divjs/divjs.js").'"></script>';

        //Bemor haqidagi ma'lumotlar
        $patient = $this->patient_uzi_model->get_patient($payment_id);
        $this->data["patient"]      = $patient;

        $payment = $this->patients_payments_model->get_patient_payment($payment_id);

        //Bemorning uzilari
        $uzi_results = $this->patient_uzi_model->get_patient_uzi($payment_id);
        $uzis = array();

        foreach ($uzi_results as $uzi) {
            $uzis[$uzi["payment_id"]][] = $uzi;
        }

        $this->data["uzis"]   = $uzis;


        $this->render('doctor/patients_uzi/patient_info_view');
    }

    public function patient_info_all($patient_id)
    {
        $this->data["refer"] = site_url("doctor/patients_uzi/all");

        $this->data['before_themeStyle'] = '<link rel="stylesheet" type="text/css" href="'.site_url("assets/doctor/js/print.min.css").'">';
        $this->data['before_appjs'] = '<script src="'.site_url("assets/doctor/js/print.min.js").'"></script>';

        //Bemor haqidagi ma'lumotlar
        $patient = $this->patients_model->get_patient($patient_id);
        $this->data["patient"]      = $patient;

        //Bemorning uzilari
        $uzi_results = $this->patient_uzi_model->get_patient_uzi_by_patient($patient_id);
        $uzis = array();

        foreach ($uzi_results as $uzi) {
            $uzis[$uzi["payment_id"]][] = $uzi;
        }

        $this->data["uzis"]   = $uzis;


        $this->render('doctor/patients_uzi/patient_info_all_view');
    }


    public function ajax_patient_uzi_status()
    {
        $payment_id         = $this->input->post("payment_id");
        $uzi_status         = $this->input->post("doctor_status");
//        $patient_doctor_id  = $this->input->post("patient_doctor_id");

        //order_status = 0-navbatda, 1-doctor qabulida, 2-laboratoriyada, 3-uzida, 4-finish
        //doctor_status = 0-tulov qilinmagan, 1-tulov qilingan, 2-tamomlangan, 3-qabul kirdi
        if($uzi_status == "qabulda") {
            $this->patients_payments_model->update($payment_id, array("order_status" => 3, "uzi_status" => 3));
        } elseif ($uzi_status == "qabul_tamom") {
            $this->patient_uzi_model->update_status($payment_id, array("status" => 1));
            $this->patients_payments_model->update($payment_id, array("uzi_status" => 2));

            $payment_status     = $this->patients_payments_model->check_payment_status($payment_id);
            if($payment_status == 'completed') {
                $this->patients_payments_model->update($payment_id, array("status" => 1, "order_status" => 4));
            } else {
                $this->patients_payments_model->update($payment_id, array("order_status" => 0));
            }
        }

        echo json_encode($uzi_status);
    }

    public function ajax_save_uzi_result() {
        $id = $this->input->post("id");
        $result = $this->input->post("result");

        $res = $this->patient_uzi_model->update($id, array("result" => $result));

        echo json_encode($res);
        
    }

    //preview button bosilganda payment id buyicha laboratoriyalar natijalarining tablitsasi
    public function ajax_print_preview() {
        $payment_id     = $this->input->post("payment_id");
        $this->load->helper("lab_form");
        $html = build_uzi_results($payment_id);

        echo json_encode($html);
    }

    public function patient_edit($patient_id)
    {
		$this->data["title"] = "Бемор тахрирлаш";
		$this->data['before_themeStyle'] = '
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/select2.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/css/bootstrap-datetimepicker.min.css").'">
        <link rel="stylesheet" type="text/css" href="'.site_url("assets/admin/js/lou_multi_select/multi-select.css").'">
        ';

		$this->data['before_appjs'] = '
        <script src="'.site_url("assets/admin/js/select2.min.js").'"></script>
        <script src="'.site_url("assets/admin/js/moment.min.js").'"></script>
        <script src="'.site_url("assets/admin/js/bootstrap-datetimepicker.min.js").'"></script>
        <script src="'.site_url("assets/admin/js/lou_multi_select/jquery.multi-select.js").'"></script>
                                        ';

		$patient    = $this->patients_model->get_patient($patient_id);
		$user_id    = $patient["user_id"];
		$this->data["patient"] = $patient;

		//Viloyatlar
		$this->data['regions'] = $this->regions_model->get_regions_array();

		//Shaxarlar
		$this->data['cities'] = $this->cities_model->get_cities_by_region_id($patient["region_id"]);

		$this->data["days"] 	= days_of_month();
		$this->data["months"] 	= months_of_year();
		$this->data["years"] 	= get_years();

		$was_validated = "";

		// validate form input
		$this->form_validation->set_rules('first_name', $this->lang->line('create_user_validation_fname_label'), 'trim|required');
		$this->form_validation->set_rules('last_name', $this->lang->line('create_user_validation_lname_label'), 'trim|required');
		$this->form_validation->set_rules('phone', $this->lang->line('create_user_validation_phone_label'), 'trim');
		$this->form_validation->set_rules('dob', $this->lang->line('create_user_validation_department_label'), 'trim');

		if ($this->form_validation->run() === TRUE)
		{
			$additional_data = [
				'first_name'    => $this->input->post('first_name'),
				'last_name'     => $this->input->post('last_name'),
				'dob'           => $this->input->post('dob_year').'-'.$this->input->post('dob_month').'-'.$this->input->post('dob_day'),
			];

			//bemorni yangilash Users table
			$this->ion_auth->update($user_id, $additional_data);

			// check to see if we are creating the user
			// redirect them back to the admin page
			$this->session->set_flashdata('message', $this->ion_auth->messages());
			redirect("doctor/patients_uzi", 'refresh');

		}
		else
		{
			// display the create user form
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

			if(!empty($this->data['message'])) {
				$was_validated = "was-validated";
			}
			$this->data["was_validated"] = $was_validated;
			$this->data['first_name'] = [
				'name'  => 'first_name',
				'id'    => 'first_name',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('first_name', $patient["first_name"]),
				"class" => "form-control",
				"required" => ""
			];
			$this->data['last_name'] = [
				'name' => 'last_name',
				'id' => 'last_name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('last_name', $patient["last_name"]),
				"class" => "form-control",
				"required" => ""
			];
			$this->data['dob_day'] = [
				'name' => 'dob_day',
				'id' => 'dob_day',
				'type' => 'text',
				'value' => $this->form_validation->set_value('dob_day', intval(date("d", strtotime($patient["dob"])))),
				'class' => 'form-control select select2_search',
			];
			$this->data['dob_month'] = [
				'name' => 'dob_month',
				'id' => 'dob_month',
				'type' => 'text',
				'value' => $this->form_validation->set_value('dob_month', date("m", strtotime($patient["dob"]))),
				'class' => 'form-control select select2_search',
			];
			$this->data['dob_year'] = [
				'name' => 'dob_year',
				'id' => 'dob_year',
				'type' => 'text',
				'value' => $this->form_validation->set_value('dob_year', date("Y", strtotime($patient["dob"]))),
				'class' => 'form-control select select2_search',
			];
			$this->data['region'] = [
				'name' => 'region_id',
				'id' => 'region_id',
				'type' => 'text',
				'value' => $this->form_validation->set_value('region_id', $patient["region_id"]),
				'class' => 'custom-select',
				"required" => "required",
				"data-url" => site_url("admin/doctors/ajax_get_cities")

			];
			$this->data['city'] = [
				'name'  => 'city_id',
				'id'    => 'city_id',
				'value' => $this->form_validation->set_value('city_id', $patient["city_id"]),
				'class' => 'custom-select',
				"required" => ""
			];
			$this->data['phone'] = [
				'name' => 'phone',
				'id' => 'phone',
				'type' => 'text',
				'value' => $this->form_validation->set_value('phone', $patient["phone"]),
				'class' => 'form-control',
			];
		}

		$this->render('doctor/patients_uzi/patient_edit_view');
    }


}
