<?php $this->load->view('admin/reports/header_template_view'); ?>
<div class="row">
	<div class="col-md-12">
		<table class="table">
			<thead>
			<tr>
				<th width="15%">Чек №</th>
				<th width="20%">Бемор</th>
				<th width="15%">Тўланган вақт</th>
				<th width="15%">Хизмат тури</th>
				<th class="text-right">Тўланган қарз</th>
			</tr>
			</thead>
			<tbody>
			<?php $total = 0; ?>
			<?php if(count($patients) > 0) { ?>
			<?php foreach ($patients as $patient) { ?>
			<tr>
				<td><?= $patient["payment_id"]; ?></td>
				<td><?= $patient["last_name"] ." ". $patient["first_name"]; ?></td>
				<td><?= date("d.m.Y H:i", strtotime($patient["debt_off_date"])); ?></td>
				<td>Шифокор кўриги</td>
				<td class="text-right"><?= $patient["paid"]; ?></td>
			</tr>
			<?php $total += $patient["paid"]; ?>
			<?php } ?>
			<?php } else { ?>
				<tr><td colspan="7" class="text-center p-4">Маълумот топилмади</td></tr>
			<?php } ?>

			</tbody>
			<?php if(count($patients) > 0) {?>
				<tfoot>
				<tr>
					<td colspan="6" class="text-right bg-header font-18 font-weight-bold"><?= money_formatting($total); ?></td>
				</tr>
				</tfoot>
			<?php } ?>
		</table>
	</div>
</div>
<?php $this->load->view('admin/reports/footer_template_view'); ?>
