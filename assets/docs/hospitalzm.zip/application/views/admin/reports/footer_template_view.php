
            </div><!-- //tab-content -->
        </div><!-- //card-box -->
    </div><!-- //col-md-12 -->

	<?= form_open("", array("class" => "w-100")); ?>
	<div class="col-md-12">
		<div class="card-box">
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group">
						<div class="cal-icon"><?php echo form_input($start_date);?></div>
						<div class="invalid-feedback"><?php echo form_error('start_date'); ?></div>
					</div>
				</div>
				<div class="col-sm-5">
					<div class="form-group">
						<div class="cal-icon"><?php echo form_input($end_date);?></div>
						<div class="invalid-feedback"><?php echo form_error('end_date'); ?></div>
					</div>
				</div>
				<div class="col-sm-2">
					<div class="form-group">
						<button type="submit" name="show_report" class="btn btn-primary btn-block">Кўрсатиш</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?= form_close(); ?>

</div><!-- //row mb-4 -->

