<?= $breadcrumbs; ?>
<div class="row">
	<div class="col-md-12">
		<table class="table">
			<thead>
			<tr>
                <th width="20%">Чек №</th>
                <th width="20%">Бемор</th>
                <th width="15%">Сана</th>
				<th class="text-right">Тушум</th>
			</tr>
			</thead>
			<tbody>
			<?php $total = 0; ?>
            <?php foreach ($patients as $patient) {?>
                <?php $payment = is_null($patient["debt"]) ? $patient["price"]:$patient["real_payment"]; ?>
                <tr>
                    <td><?= $patient["payment_id"]; ?></td>
                    <td><?= $patient["patient_last_name"] .' '. $patient["patient_first_name"]; ?></td>
                    <td><?= date("d.m.Y H:i", strtotime($patient["created_date"])); ?></td>
                    <td class="text-right"><?= money_formatting($payment); ?></td>
                </tr>
                <?php $total += $payment; ?>
            <?php } ?>
			</tbody>

			<tfoot>
			<tr>
				<td colspan="6" class="text-right bg-header font-18 font-weight-bold"><?= money_formatting($total); ?></td>
			</tr>
			</tfoot>
		</table>
	</div>
</div>

