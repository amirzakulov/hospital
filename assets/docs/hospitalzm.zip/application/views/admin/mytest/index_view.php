<style>
    /*span {display: block;}*/
</style>
<div class="row">
    <div class="col-md-12">
        <?php

//		$this->load->library('ReceiptPrint');
//
//		$lab_items = [];
//		foreach ($pr["laboratory_items"] as $k => $litem) {
//
//			if($k === 'total') {
//				$lab_items[] = new doubleColumn($litem["text"], $litem["price"]);
//			} elseif($k == 0) {
//				$lab_items[] = new singleColumn($litem["text"]);
//			} else {
//				$lab_items[] = new singleColumn($litem["text"]);
//				$lab_items[] = new singleColumn( $litem["count"]." x ".$litem["price"]. " = ".($litem["count"] * $litem["price"]), STR_PAD_LEFT);
//			}
//		}
//
//		echo "<pre>";
//		print_r($lab_items);
//		echo "</pre>";

//		echo "<pre>";
//		print_r($text);
//		echo "</pre>";
//		echo "<pre>";
//		print_r(mb_strlen($text));
//		echo "</pre>";
//
//		echo "<pre>";
//		print_r($text2);
//		echo "</pre>";
//		echo "<pre>";
//		print_r(mb_strlen($text2));
//		echo "</pre>";
//
//		echo "<pre>";
//		print_r($text3);
//		echo "</pre>";
//		echo "<pre>";
//		print_r(mb_strlen($text3));
//		echo "</pre>";
//
//		echo "<pre>";
//		print_r($text4);
//		echo "</pre>";
//		echo "<pre>";
//		print_r(mb_strlen($text4));
//		echo "</pre>";



		?>
    </div>

</div>
